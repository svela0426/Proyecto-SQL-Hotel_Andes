package uniandes.isis2304.hotelandes.negocio;

public interface VOTipoHabitacion {

	
	
	public String getTipoHabitacion();


	public long getCapacidad();


	public long getArea();

	@Override
	public String toString();
	
	
	
	
	
}
