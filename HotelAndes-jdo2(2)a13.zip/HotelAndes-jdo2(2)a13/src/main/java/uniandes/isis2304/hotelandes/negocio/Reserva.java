package uniandes.isis2304.hotelandes.negocio;

import java.sql.Timestamp;

public class Reserva implements VOReserva

{
	private long idReserva;
	
	
	private Timestamp fechaEntrada;
	
	private Timestamp fechaSalida;

	
	private int numeroPersonas;
	
	private long idCliente;
	
	
	public Reserva() 
	{
		this.idReserva = 0;
		this.fechaEntrada = new Timestamp (0);
		this.fechaSalida = new Timestamp (0);
		this.numeroPersonas = 0;
		this.idCliente = 0;
	}
	
	public Reserva(long idReserva, Timestamp fechaEntrada,Timestamp fechaSalida,int numeroPersonas,long idCliente) 
	{
		this.idReserva = idReserva;
		this.fechaEntrada = fechaEntrada;
		this.fechaSalida = fechaSalida;
		this.numeroPersonas =  numeroPersonas;
		this.idCliente = idCliente;	
		}

	public long getIdReserva() {
		return idReserva;
	}

	public void setIdReserva(long idReserva) {
		this.idReserva = idReserva;
	}

	public Timestamp getFechaEntrada() {
		return fechaEntrada;
	}

	public void setFechaEntrada(Timestamp fechaEntrada) {
		this.fechaEntrada = fechaEntrada;
	}

	public Timestamp getFechaSalida() {
		return fechaSalida;
	}

	public void setFechaSalida(Timestamp fechaSalida) {
		this.fechaSalida = fechaSalida;
	}

	public long getNumeroPersonas() {
		return numeroPersonas;
	}

	public void setNumeroPersonas(int numeroPersonas) {
		this.numeroPersonas = numeroPersonas;
	}

	public long getIdCliente() {
		return idCliente;
	}

	public void setIdCliente(long idCliente) {
		this.idCliente = idCliente;
	}

	@Override
	public String toString() {
		return "Reserva [idReserva=" + idReserva + ", fechaEntrada=" + fechaEntrada + ", fechaSalida=" + fechaSalida
				+ ", numeroPersonas=" + numeroPersonas + ", idCliente=" + idCliente + "]";
	}
	
	
	
	
	
	
	



	
	

	
	
	

}
