package uniandes.isis2304.hotelandes.negocio;

public class HabitacionReservada implements VOHabitacionReservada

{
	
	private long idHabitacion;
	
	private long idReserva;
	
	private long idCuenta;
	
	
	public HabitacionReservada() 
    {
    	this.idHabitacion = 0;   
    	this.idReserva = 0;
    	this.idCuenta = 0;   


	}
	
	
	public HabitacionReservada(long idHabitacion,long idReserva,long idCuenta) 
    {
		this.idHabitacion = idHabitacion;   
    	this.idReserva = idReserva;
    	this.idCuenta = idCuenta;   
	}


	public long getIdHabitacion() {
		return idHabitacion;
	}


	public void setIdHabitacion(long idHabitacion) {
		this.idHabitacion = idHabitacion;
	}


	public long getIdReserva() {
		return idReserva;
	}


	public void setIdReserva(long idReserva) {
		this.idReserva = idReserva;
	}


	public long getIdCuenta() {
		return idCuenta;
	}


	public void setIdCuenta(long idCuenta) {
		this.idCuenta = idCuenta;
	}


	@Override
	public String toString() {
		return "HabitacionReservada [idHabitacion=" + idHabitacion + ", idReserva=" + idReserva + ", idCuenta="
				+ idCuenta + "]";
	}
	
	
	
	
	
	


}



