package uniandes.isis2304.hotelandes.negocio;


public class Cuenta  implements VOCuenta


{
	
	private long idCuenta;	
	
	private int total;	
	
	public Cuenta() 
	{
		this.idCuenta = 0;
		this.total = 0;

	}
	
	public Cuenta(long idCuenta, int total) 
	{
		this.idCuenta = idCuenta;
		this.total = total;

	}

	public long getIdCuenta() {
		return idCuenta;
	}

	public void setIdCuenta(long idCuenta) {
		this.idCuenta = idCuenta;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	@Override
	public String toString() {
		return "Cuenta [idCuenta=" + idCuenta + ", total=" + total + "]";
	}
	
	
	
	
		

	

}
