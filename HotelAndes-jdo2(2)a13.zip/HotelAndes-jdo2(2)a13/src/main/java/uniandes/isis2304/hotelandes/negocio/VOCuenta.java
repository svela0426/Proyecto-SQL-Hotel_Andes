package uniandes.isis2304.hotelandes.negocio;

public interface VOCuenta {
	
	
	public long getIdCuenta();


	public int getTotal();



	@Override
	public String toString();

}
