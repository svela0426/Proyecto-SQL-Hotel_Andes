package uniandes.isis2304.hotelandes.negocio;

import java.sql.Timestamp;

public interface VOReserva {
	
	
	public long getIdReserva();

	public Timestamp getFechaEntrada();

	public Timestamp getFechaSalida();

	public long getNumeroPersonas();

	public long getIdCliente();

	@Override
	public String toString();
	
	
	

}
