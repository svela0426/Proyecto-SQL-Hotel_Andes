package uniandes.isis2304.hotelandes.negocio;

public interface VOHabitacionOfertada {
	
	
	
	public long getIdHotel();


	


	public long getIdHabitacion();




	@Override
	public String toString();
}
