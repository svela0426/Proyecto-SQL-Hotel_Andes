package uniandes.isis2304.hotelandes.negocio;

public interface VOEmpleadoActivo {
	
	
	
	public long getIdHotel() ;


	public long getIdEmpleado();


	@Override
	public String toString();


}
