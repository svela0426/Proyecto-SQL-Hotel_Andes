package uniandes.isis2304.hotelandes.negocio;

public interface VOHabitacionReservada {
	
	
	public long getIdHabitacion();



	public long getIdReserva();



	public long getIdCuenta();




	@Override
	public String toString();
	
	
	
	

}
