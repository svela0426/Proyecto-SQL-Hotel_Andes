package uniandes.isis2304.hotelandes.negocio;

public interface VOServicioOfrecido {
	
	public long getIdServicio();


	public long getIdHotel();


	@Override
	public String toString();
	

}
