package uniandes.isis2304.hotelandes.negocio;

public interface VOCuentaCargada 
{
	
	
	public long getIdCuenta();

	
	public long getIdServicio();
	
	


	@Override
	public String toString();
}
