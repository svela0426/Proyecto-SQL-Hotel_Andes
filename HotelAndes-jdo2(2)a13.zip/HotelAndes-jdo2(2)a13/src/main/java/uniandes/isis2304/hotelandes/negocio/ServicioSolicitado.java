package uniandes.isis2304.hotelandes.negocio;

public class ServicioSolicitado implements VOServicioSolicitado
{
	private long idServicio;
	
	private long numpersonas;
	
	private int Costo;
	
	
	
	public ServicioSolicitado() 
	{
		this.idServicio = 0;
		this.numpersonas = 0;
		this.Costo = 0;		
	}
	
	
	public ServicioSolicitado(long idServicio,long numpersonas,int Costo) 
	{
		this.idServicio = idServicio;
		this.numpersonas = numpersonas;
		this.Costo = Costo;		
	}


	public long getIdServicio() {
		return idServicio;
	}


	public void setIdServicio(long idServicio) {
		this.idServicio = idServicio;
	}


	public long getNumpersonas() {
		return numpersonas;
	}


	public void setNumpersonas(long numpersonas) {
		this.numpersonas = numpersonas;
	}


	public int getCosto() {
		return Costo;
	}


	public void setCosto(int costo) {
		Costo = costo;
	}


	@Override
	public String toString() {
		return "ServicioSolicitado [idServicio=" + idServicio + ", numpersonas=" + numpersonas + ", Costo=" + Costo
				+ "]";
	}
	
	

	
	

}
