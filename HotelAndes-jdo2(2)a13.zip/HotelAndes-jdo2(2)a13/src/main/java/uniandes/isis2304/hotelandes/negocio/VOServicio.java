package uniandes.isis2304.hotelandes.negocio;

public interface VOServicio {
	
	
	public long getIdServicio();

	public String getNombre();

	public String getDescripcion();

	public long getArea();

	@Override
	public String toString();
	
	



}
