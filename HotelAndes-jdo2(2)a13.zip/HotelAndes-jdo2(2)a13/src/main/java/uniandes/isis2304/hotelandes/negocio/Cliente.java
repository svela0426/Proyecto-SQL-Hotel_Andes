package uniandes.isis2304.hotelandes.negocio;


public class Cliente implements VOCliente
{
	private long idCliente;
	
	private long numero;
	
	private String nombre;

	private String apellido;
	
	private String correo;
	
	private long idMetodoPago;
	
	private long idHotel;
	
	
	
	
	public Cliente() 
    {
    	this.idCliente = 0;
    	this.numero = 0;    	
		this.nombre = "";
		this.apellido = "";
		this.correo = "";
    	this.idMetodoPago = 0;  
    	this.idHotel = 0;  

	}
	
	public Cliente(long idCliente,long numero,String nombre,String apellido,String correo,long idMetodoPago,long idHotel) 
    {
		this.idCliente = idCliente;
    	this.numero =numero ;    	
		this.nombre = nombre;
		this.apellido = apellido;
		this.correo = correo;
    	this.idMetodoPago = idMetodoPago;  
    	this.idHotel = idHotel;  
	}

	public long getId() {
		return idCliente;
	}

	public void setId(long idCliente) {
		this.idCliente = idCliente;
	}

	public long getNumero() {
		return numero;
	}

	public void setNumero(long numero) {
		this.numero = numero;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public long getIdMetodoPago() {
		return idMetodoPago;
	}

	public void setIdMetodoPago(long idMetodoPago) {
		this.idMetodoPago = idMetodoPago;
	}

	public long getIdHotel() {
		return idHotel;
	}

	public void setIdHotel(long idHotel) {
		this.idHotel = idHotel;
	}



	@Override
	public String toString() {
		return "Cliente [id=" + idCliente + ", numero=" + numero + ", nombre=" + nombre + ", apellido=" + apellido
				+ ", correo=" + correo + ", idMetodoPago=" + idMetodoPago + ", idHotel=" + idHotel + "]";
	}









	

	
	
	


}
