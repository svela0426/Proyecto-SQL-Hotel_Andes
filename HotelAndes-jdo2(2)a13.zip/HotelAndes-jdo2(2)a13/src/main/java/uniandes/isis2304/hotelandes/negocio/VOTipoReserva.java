package uniandes.isis2304.hotelandes.negocio;

public interface VOTipoReserva {
	
	

	public long getIdReserva();


	public long getIdPlanConsumo();


	@Override
	public String toString();
	
		


}
