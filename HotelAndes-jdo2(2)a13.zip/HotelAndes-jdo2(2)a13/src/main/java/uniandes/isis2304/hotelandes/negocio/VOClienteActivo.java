package uniandes.isis2304.hotelandes.negocio;

public interface VOClienteActivo 

{
	
	public long getIdCliente();



	public long getIdReserva() ;

	
	@Override
	public String toString();
	

}
