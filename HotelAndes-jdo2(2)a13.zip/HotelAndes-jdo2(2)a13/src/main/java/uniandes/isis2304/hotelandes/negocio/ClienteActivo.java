package uniandes.isis2304.hotelandes.negocio;



public class ClienteActivo  implements VOClienteActivo
{
	private long idCliente;

	private long idReserva;
	
	
	public ClienteActivo() 
	{
		this.idCliente = 0;
		this.idReserva = 0;
	}
	
	public ClienteActivo(long idCliente, long idReserva) 
	{
		this.idCliente = idCliente;
		this.idReserva = idReserva;
	}

	public long getIdCliente() {
		return idCliente;
	}

	public void setIdCliente(long idCliente) {
		this.idCliente = idCliente;
	}

	public long getIdReserva() {
		return idReserva;
	}

	public void setIdReserva(long idReserva) {
		this.idReserva = idReserva;
	}

	@Override
	public String toString() {
		return "ClienteActivo [idCliente=" + idCliente + ", idReserva=" + idReserva + "]";
	}
	

}
