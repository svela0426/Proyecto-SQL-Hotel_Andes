package uniandes.isis2304.hotelandes.negocio;

public interface VOEmpleado {
	
	public long getIdEmpleado();



	public String getNombre();



	public long getCelular();




	public String getCorreo();




	@Override
	public String toString();
	


}
