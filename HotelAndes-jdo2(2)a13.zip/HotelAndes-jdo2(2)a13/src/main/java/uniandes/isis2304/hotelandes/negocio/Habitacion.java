package uniandes.isis2304.hotelandes.negocio;

public class Habitacion implements VOHabitacion
{

	private long idHabitacion;
	
	private String nombre;
	
	private String tipoHabitacion;
	
	private long numeroHabitacion;
	
	
	private long idEmpleado;
	
	
	public Habitacion() 
    {
    	this.idHabitacion = 0;   	
		this.nombre = "";
		this.tipoHabitacion = "";
    	this.numeroHabitacion = 0;  
    	this.idEmpleado = 0;   	

	}
	
	
	public Habitacion(long idHabitacion,String nombre,String tipoHabitacion,long numeroHabitacion,long idEmpleado) 
    {
		this.idHabitacion = idHabitacion;   	
		this.nombre = nombre;
		this.tipoHabitacion = tipoHabitacion;
    	this.numeroHabitacion = numeroHabitacion;  
    	this.idEmpleado = idEmpleado;  
	}


	public long getIdHabitacion() {
		return idHabitacion;
	}


	public void setIdHabitacion(long idHabitacion) {
		this.idHabitacion = idHabitacion;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getTipoHabitacion() {
		return tipoHabitacion;
	}


	public void setTipoHabitacion(String tipoHabitacion) {
		this.tipoHabitacion = tipoHabitacion;
	}


	public long getNumeroHabitacion() {
		return numeroHabitacion;
	}


	public void setNumeroHabitacion(long numeroHabitacion) {
		this.numeroHabitacion = numeroHabitacion;
	}


	public long getIdEmpleado() {
		return idEmpleado;
	}


	public void setIdEmpleado(long idEmpleado) {
		this.idEmpleado = idEmpleado;
	}


	@Override
	public String toString() {
		return "Habitacion [idHabitacion=" + idHabitacion + ", nombre=" + nombre + ", tipoHabitacion=" + tipoHabitacion
				+ ", numeroHabitacion=" + numeroHabitacion + ", idEmpleado=" + idEmpleado + "]";
	}

	
	
	
	

	
	

	
	


	
	
}
