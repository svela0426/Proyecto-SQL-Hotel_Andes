package uniandes.isis2304.hotelandes.negocio;

public interface VOCliente
{
	
	public long getId();


	public long getNumero();


	public String getNombre() ;

	
	
	public String getApellido();


	
	
	public String getCorreo();

	

	public long getIdMetodoPago();
	
	
	
	
	
	public long getIdHotel() ;


	

	@Override
	public String toString();

}
