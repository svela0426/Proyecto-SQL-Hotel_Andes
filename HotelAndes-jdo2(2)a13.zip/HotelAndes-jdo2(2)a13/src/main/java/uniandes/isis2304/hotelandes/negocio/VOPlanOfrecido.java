package uniandes.isis2304.hotelandes.negocio;

public interface VOPlanOfrecido {
	
	
	public long getIdPlanConsumo();

	public long getIdHotel();
	@Override
	public String toString();

}
