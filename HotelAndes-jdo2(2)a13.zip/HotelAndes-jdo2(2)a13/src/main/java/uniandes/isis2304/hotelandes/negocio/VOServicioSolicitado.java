package uniandes.isis2304.hotelandes.negocio;

public interface VOServicioSolicitado {
	
	
	public long getIdServicio();


	public long getNumpersonas();


	public int getCosto();


	@Override
	public String toString();
	
	

	

}
