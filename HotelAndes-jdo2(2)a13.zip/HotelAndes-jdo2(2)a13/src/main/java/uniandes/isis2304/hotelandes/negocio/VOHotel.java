package uniandes.isis2304.hotelandes.negocio;

public interface VOHotel {
	
	
	
	public long getIdHotel();

	public String getNombre();
	
	
	public String getUbicacion();

	public String getPaginaweb();

	public long getNumero();
	
	@Override
	public String toString();
	
	

	
	
	

}
