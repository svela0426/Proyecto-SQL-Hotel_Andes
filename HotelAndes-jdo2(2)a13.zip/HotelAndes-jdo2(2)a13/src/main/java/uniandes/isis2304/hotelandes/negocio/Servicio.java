package uniandes.isis2304.hotelandes.negocio;


public class Servicio implements VOServicio
{
	
	private long idServicio;
	
	private String nombre;

	private String descripcion;

	private long area;
	
	
	
	public Servicio() 
	{
		this.idServicio = 0;
		this.nombre = "";
		this.descripcion = "";
		this.area = 0;
	}
	
	public Servicio(long idServicio, String nombre,String descripcion,long area) 
	{
		this.idServicio = idServicio;
		this.nombre = nombre;
		this.descripcion = descripcion;
		this.area = area;
		}

	public long getIdServicio() {
		return idServicio;
	}

	public void setIdServicio(long idServicio) {
		this.idServicio = idServicio;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public long getArea() {
		return area;
	}

	public void setArea(long area) {
		this.area = area;
	}

	@Override
	public String toString() {
		return "Servicio [idServicio=" + idServicio + ", nombre=" + nombre + ", descripcion=" + descripcion + ", area="
				+ area + "]";
	}
	
	
	
	



}
