package uniandes.isis2304.hotelandes.persistencia;

import java.util.List;

import javax.jdo.PersistenceManager;
import javax.jdo.Query;

import uniandes.isis2304.hotelandes.negocio.Cliente;

public class SQLCliente {

	private final static String SQL = PersistenciaHotelAndes.SQL;

	private PersistenciaHotelAndes ph;

	public SQLCliente (PersistenciaHotelAndes ph)
	{
		this.ph = ph;
	}
	
	public long adicionarCliente (PersistenceManager pm, long idCliente, long numero,String nombre,String apellido,String correo,long idMetodoPago,long idHotel) 
	{
        Query q = pm.newQuery(SQL, "INSERT INTO " + ph.darTablaCliente () + "(idCliente, Numero, Nombre, Apellido, Correo, idMetodoPago, idHotel, idReserva) values (?, ?, ?, ?, ?, ?, ?)");
        q.setParameters(idCliente);
        return (long) q.executeUnique();
	}
	
	public Cliente darClientePorId (PersistenceManager pm, long idCliente) 
	{
		Query q = pm.newQuery(SQL, "SELECT * FROM " + ph.darTablaCliente () + " WHERE id = ?");
		q.setResultClass(Cliente.class);
		q.setParameters(idCliente);
		return (Cliente) q.executeUnique();
	}
	
	public long eliminarClientePorId (PersistenceManager pm, long idCliente)
	{
        Query q = pm.newQuery(SQL, "DELETE FROM " + ph.darTablaCliente () + " WHERE id = ?");
        q.setParameters(idCliente);
        return (long) q.executeUnique();            
	}
	
	public long eliminarClientePorNumero (PersistenceManager pm, String numero)
	{
        Query q = pm.newQuery(SQL, "DELETE FROM " + ph.darTablaCliente () + " WHERE numero = ?");
        q.setParameters(numero);
        return (long) q.executeUnique();            
	}
	
	public long eliminarClientePorNombre (PersistenceManager pm, String nombre)
	{
        Query q = pm.newQuery(SQL, "DELETE FROM " + ph.darTablaCliente () + " WHERE nombre = ?");
        q.setParameters(nombre);
        return (long) q.executeUnique();            
	}
	
	public long eliminarClientePorApellido (PersistenceManager pm, String apellido)
	{
        Query q = pm.newQuery(SQL, "DELETE FROM " + ph.darTablaCliente () + " WHERE apellido = ?");
        q.setParameters(apellido);
        return (long) q.executeUnique();            
	}
	
	public long eliminarClientePorCorreo (PersistenceManager pm, String correo)
	{
        Query q = pm.newQuery(SQL, "DELETE FROM " + ph.darTablaCliente () + " WHERE correo = ?");
        q.setParameters(correo);
        return (long) q.executeUnique();            
	}
	
	public long eliminarClientePorIdMetodoPago (PersistenceManager pm, String idMetodoPago)
	{
        Query q = pm.newQuery(SQL, "DELETE FROM " + ph.darTablaCliente () + " WHERE id = ?");
        q.setParameters(idMetodoPago);
        return (long) q.executeUnique();            
	}
	
	public long eliminarClientePorIdHotel (PersistenceManager pm, String idHotel)
	{
        Query q = pm.newQuery(SQL, "DELETE FROM " + ph.darTablaCliente () + " WHERE id = ?");
        q.setParameters(idHotel);
        return (long) q.executeUnique();            
	}
	

	
	public List<Cliente> darCliente (PersistenceManager pm)
	{
		Query q = pm.newQuery(SQL, "SELECT * FROM " + ph.darTablaCliente ());
		q.setResultClass(Cliente.class);
		return (List<Cliente>) q.executeList();
	}
	
	public List<Cliente> darClientePorNumero (PersistenceManager pm, long numero) 
	{
		Query q = pm.newQuery(SQL, "SELECT * FROM " + ph.darTablaCliente () + " WHERE numero = ?");
		q.setResultClass(Cliente.class);
		q.setParameters(numero);
		return (List<Cliente>) q.executeList();
	}
	
	public List<Cliente> darClientePorNombre (PersistenceManager pm, String nombre) 
	{
		Query q = pm.newQuery(SQL, "SELECT * FROM " + ph.darTablaCliente () + " WHERE nombre = ?");
		q.setResultClass(Cliente.class);
		q.setParameters(nombre);
		return (List<Cliente>) q.executeList();
	}
	
	public List<Cliente> darClientePorApellido (PersistenceManager pm, String apellidoCliente) 
	{
		Query q = pm.newQuery(SQL, "SELECT * FROM " + ph.darTablaCliente () + " WHERE apellido = ?");
		q.setResultClass(Cliente.class);
		q.setParameters(apellidoCliente);
		return (List<Cliente>) q.executeList();
	}
	
	public List<Cliente> darClientePorCorreo (PersistenceManager pm, String correoCliente) 
	{
		Query q = pm.newQuery(SQL, "SELECT * FROM " + ph.darTablaCliente () + " WHERE correo = ?");
		q.setResultClass(Cliente.class);
		q.setParameters(correoCliente);
		return (List<Cliente>) q.executeList();
	}
	
	public List<Cliente> darClientePorIdMetodoPago (PersistenceManager pm, long idMetodoPagoCliente) 
	{
		Query q = pm.newQuery(SQL, "SELECT * FROM " + ph.darTablaCliente () + " WHERE id = ?");
		q.setResultClass(Cliente.class);
		q.setParameters(idMetodoPagoCliente);
		return (List<Cliente>) q.executeList();
	}
	
	public List<Cliente> darClientePorIdHotel (PersistenceManager pm, long idHotelCliente) 
	{
		Query q = pm.newQuery(SQL, "SELECT * FROM " + ph.darTablaCliente () + " WHERE id = ?");
		q.setResultClass(Cliente.class);
		q.setParameters(idHotelCliente);
		return (List<Cliente>) q.executeList();
	}
	
	

}
