package uniandes.isis2304.hotelandes.negocio;

public interface VOMetododePago {
	
	
	

	public long getIdMetodoPago();


	public String getTipo();


	public String getNombre();


	@Override
	public String toString();

}
