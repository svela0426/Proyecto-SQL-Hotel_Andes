package uniandes.isis2304.hotelandes.negocio;

public class TipoHabitacion implements VOTipoHabitacion
{
	
	private String tipoHabitacion;

	
	private long capacidad;

	
	private long area;

	
	
	public TipoHabitacion() 
    {
    	  	
		this.tipoHabitacion = "";
		this.capacidad = 0;
    	this.area = 0;    	

	}
	
	
	public TipoHabitacion(String tipoHabitacion,long capacidad,long area) 
    {
		
		this.tipoHabitacion = tipoHabitacion;
		this.capacidad = capacidad;
    	this.area = area;  
	 
	}


	public String getTipoHabitacion() {
		return tipoHabitacion;
	}


	public void setTipoHabitacion(String tipoHabitacion) {
		this.tipoHabitacion = tipoHabitacion;
	}


	public long getCapacidad() {
		return capacidad;
	}


	public void setCapacidad(long capacidad) {
		this.capacidad = capacidad;
	}


	public long getArea() {
		return area;
	}


	public void setArea(long area) {
		this.area = area;
	}


	@Override
	public String toString() {
		return "TipoHabitacion [tipoHabitacion=" + tipoHabitacion + ", capacidad=" + capacidad + ", area=" + area + "]";
	}
	
	
	
	
	
	
	
	
	

}
