package uniandes.isis2304.hotelandes.negocio;

public interface VOHabitacion {
	
	
	
	public long getIdHabitacion();



	public String getNombre();





	public String getTipoHabitacion();



	public long getNumeroHabitacion();




	public long getIdEmpleado();


	@Override
	public String toString();

	
	

}
