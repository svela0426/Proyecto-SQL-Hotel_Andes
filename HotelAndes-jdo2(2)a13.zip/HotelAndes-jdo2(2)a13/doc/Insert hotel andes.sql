INSERT INTO A_HOTEL (idHotel, nombre, ubicacion, paginaweb, NUMERO) 
VALUES (1048, 'HotelAndes','Bogota','www.hotelandes.com.co', 3004561234);



INSERT INTO A_EMPLEADO (idEmpleado, nombre, CELULAR, CORREO) 
VALUES (842, 'Jose', 3248563978 ,'Joseruales83@gmail.com');


INSERT INTO A_METODO_PAGO (idMetodoPago, tipo, nombre)
VALUES (3,'Tarjeta', 'MasterCard');


INSERT INTO A_CUENTA (idCuenta, total) 
VALUES (7561, 1500000);



INSERT INTO A_PLAN_CONSUMO (idPlanConsumo, nombre, costo, vigencia) 
VALUES (147, 27, '2500000', '31/07/2021');



INSERT INTO A_SERVICIO_SOLICITADO (idServicio, numpersonas, Costo)
VALUES (49, 1, 200.000);



INSERT INTO A_SERVICIO (idServicio, nombre, DESCRIPCION, area)
VALUES (49, 'Sauna','Sauna grande','Recreación');



INSERT INTO A_TIPO_HABITACION (tipoHabitacion, CAPACIDAD, AREA)
VALUES ('Sencilla ', 1, 20);



INSERT INTO A_HABITACION (idHabitacion, nombre, CAPACIDAD, tipoHabitacion, numeroHabitacion, idEmpleado) 
VALUES (1003, 'Habitacion Especial',1,1,703,842);


INSERT INTO A_HABITACION_OFERTADA (idHotel, idHabitacion) 
VALUES (1048, 1003);


INSERT INTO A_CLIENTE (idCliente, numero, NOMBRE, APELLIDO, CORREO, idMetodoPago, idHotel) 
VALUES (1001, 7841, 'Ruben', 'Sanchez', 'Rubensanchez1991@gmail.com', 3, 1048);



INSERT INTO A_RESERVA (idReserva, fechaEntrada, fechaSalida, numeroPersonas, idCliente)
VALUES (71564, '17/07/2021','30/07/2021', 1, 1001);



INSERT INTO A_TIPO_RESERVA (idReserva, idPlanConsumo)
VALUES (71564, 147);



INSERT INTO A_HABITACION_RESERVADA (idHabitacion, idReserva, idCuenta) 
VALUES (1003, 71564, 7561);



INSERT INTO A_SERVICIO_OFRECIDO (idServicio, idHotel)
VALUES (49, 1048);



INSERT INTO A_CLIENTE_ACTIVO (idCliente, idReserva) 
VALUES (1001, 71564);


INSERT INTO A_EMPLEADO_ACTIVO (idHotel, idEmpleado) 
VALUES (1048, 842);




INSERT INTO A_CUENTA_CARGADA (idCuenta, idServicio) 
VALUES (7561, 49);




INSERT INTO A_PLAN_OFRECIDO (idPlanConsumo, idHotel)
VALUES (147, 1048)


