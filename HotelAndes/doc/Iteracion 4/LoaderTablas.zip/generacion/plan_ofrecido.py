import random
import csv
from datetime import datetime

mayor=[]

for j in range(0,49994):

    lili=[]
    lili.append(j)
    lili.append(random.randint(1,9000))
    mayor.append(lili)
    lili=[]

print(len(mayor))


myFile = open('a_plan_ofrecido.csv', 'w')
with myFile:
    writer = csv.writer(myFile)
    writer.writerows(mayor)
     
print("Writing complete")



