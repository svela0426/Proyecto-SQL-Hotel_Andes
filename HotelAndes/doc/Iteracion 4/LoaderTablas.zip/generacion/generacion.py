import random
import csv


ciudades=[]

with open('hoteles info.csv') as File:
    reader = csv.reader(File, delimiter=';', quotechar=';',
                        quoting=csv.QUOTE_MINIMAL)
    cc=[]                    
    for row in reader:
        cc.append(row)


for i in range(1,len(cc)):

    ciudades.append(cc[i][2])
 
ciudades.pop(0)



longitud=len(ciudades)

longitud-=1





lista=[]
lili=[]


for i in range(1,10001):

    h="hotel "
    lista1=[]
    lista1.append(i)

    h=h + chr(random.randint(ord('A'), ord('Z')))

    vocal=random.choice("aeou")

    h=h+vocal

    pp=random.choice("wrtypsdfghjklzcvbnm")
    h =h+ pp
    h=h+vocal
    h=h+chr(random.randint(ord('a'), ord('z')))
    h =h+ pp
    h=h+vocal
    h=h+chr(random.randint(ord('a'), ord('z')))
    h=h+vocal
    h=h+chr(random.randint(ord('a'), ord('z')))
    h=h+vocal
    h=h+chr(random.randint(ord('a'), ord('z')))
    h=h+chr(random.randint(ord('a'), ord('z')))


    if h not in lili:

       lili.append(h)

       num=random.randint(0, longitud)
       lista1.append(h)
       lista1.append(ciudades[num])
       lista1.append("wwww."+h+"/.com")
       lista1.append(random.randint(3000000000, 3200000000))
       lista.append(lista1)
       lista1=[]


       h="hotel"





myFile = open('a_hotel.csv', 'w')
with myFile:
    writer = csv.writer(myFile)
    writer.writerows(lista)
     
print("Writing complete")
    
    







