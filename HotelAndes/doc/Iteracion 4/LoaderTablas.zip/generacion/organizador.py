import random
import csv


mayor=[]
for q in range(250001,300001):

    lili=[]
    lili.append(q)
    lili.append(random.randint(1,90000))

    mayor.append(lili)
    lili=[]

print(len(mayor))


myFile = open('a_organizador.csv', 'w')
with myFile:
    writer = csv.writer(myFile)
    writer.writerows(mayor)
     
print("Writing complete")