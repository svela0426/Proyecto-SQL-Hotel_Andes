import random
import csv
from datetime import datetime


with open('a_metodo_pago.csv') as File:
    reader = csv.reader(File, delimiter=',', quotechar=',',
                        quoting=csv.QUOTE_MINIMAL)
    cc=[]                    
    for row in reader:
        cc.append(row[0])



mayor=[]
for i in range(1,100000):

    lista=[]
    lista.append(i)
    lista.append(cc[i])
    lista.append(random.randint(1,10000))
    lista.append(random.randint(1,10000))
    mayor.append(lista)
    lista=[]



myFile = open('a_cliente.csv', 'w')
with myFile:
    writer = csv.writer(myFile)
    writer.writerows(mayor)
     
print("Writing complete")



    
