import csv
import random
from datetime import datetime



with open('elements.csv') as File:
    reader = csv.reader(File, delimiter=';', quotechar=';',
                        quoting=csv.QUOTE_MINIMAL)
    lista=[]                    
    for row in reader:
        lista.append(row[0])


lista=lista[2:]

lola=[]

for i in lista:

    lola.append(i[:-1])

inicio = datetime(1990, 1, 30)
final =  datetime(2030, 5, 28)


mayor=[]
prove=[]
for i in range(1,50001):
    h="Plan "
    lista1=[]
    lista1.append(i)
    h=h+random.choice(lola)
    h=h+chr(random.randint(ord('A'), ord('Z')))
    h=h+chr(random.randint(ord('A'), ord('Z')))
    h=h+chr(random.randint(ord('A'), ord('Z')))
    h=h+chr(random.randint(ord('A'), ord('Z')))
    h=h+chr(random.randint(ord('A'), ord('Z')))
    if h not in prove:
        prove.append(h)
        lista1.append(h)
        lista1.append(random.randint(3000000000, 8200000000))
        random_date = inicio + (final - inicio) * random.random()

        pala=""
        day = str(random_date.day)
        pala=day+'/'
        mes = str(random_date.month)
        pala=pala+mes+'/'
        anio= str(random_date.year)
        pala=pala+anio
        lista1.append(pala)



        mayor.append(lista1)
        lista1=[]


        
    
myFile = open('a_plan_consumo.csv', 'w')
with myFile:
    writer = csv.writer(myFile)
    writer.writerows(mayor)
     
print("Writing complete")





