import random
import csv
from datetime import datetime
from secrets import choice


inicio = datetime(2012, 1, 30)
final =  datetime(2014, 5, 28)

estados=['Activo','Inactivo','Pasada']



mayor=[]
for i in range(1,50000):
    lista=[]
    lista.append(i)

    random_date = inicio + (final - inicio) * random.random()
    random_date1 = inicio + (final - inicio) * random.random()


    pla=""
    day = str(random_date.day)
    pla=day+'/'
    mes = str(random_date.month)
    pla=pla+mes+'/'
    anio= str(random_date.year)
    pla=pla+anio

    pla1=""
    day1 = str(random_date1.day)
    pla1=day1+'/'
    mes1 = str(random_date1.month)
    pla1=pla1+mes1+'/'
    anio1= str(random_date1.year)
    pla1=pla1+anio1

    if  anio <anio1  :
        lista.append(pla)
        lista.append(pla1)
    elif anio == anio1 :
        if mes <mes1:
            lista.append(pla)
            lista.append(pla1)
        else:
            lista.append(pla1)
            lista.append(pla)

    else:
            lista.append(pla1)
            lista.append(pla)


    lista.append(random.randint(2, 8))
    lista.append(random.randint(1, 100000))
    lista.append(random.randint(1, 10000))
    lista.append(random.choice(estados))

    mayor.append(lista)
    lista=[]



myFile = open('a_reserva.csv', 'w')
with myFile:
    writer = csv.writer(myFile)
    writer.writerows(mayor)
     
print("Writing complete")

