import random
import csv
from datetime import datetime
from secrets import choice

p="10000h"

h="49 999 hab"

t=0
m=5
mayor=[]

for i in range(10000):
    lista=[]
    for j in range(t,m):
        lista.append(i)
        lista.append(j)
        mayor.append(lista)
        lista=[]

    t+=5  
    m+=5 

myFile = open('a_habitacion_ofertada.csv', 'w')
with myFile:
    writer = csv.writer(myFile)
    writer.writerows(mayor)
     
print("Writing complete")

    


