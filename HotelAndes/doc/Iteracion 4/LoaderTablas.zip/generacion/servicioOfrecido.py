import random
import csv
from datetime import datetime
from secrets import choice

10000
1782

mayor=[]
for i in range(200,400):
    lista1=[]
    for j in range(1,5000):
        lista1.append(i)
        lista1.append(j)
        mayor.append(lista1)
        lista1=[]

for i in range(400,700):
    lista=[]
    for j in range(5000,10000):
        lista.append(i)
        lista.append(j)
        mayor.append(lista)
        lista=[]



    
myFile = open('a_servicio_ofrecidoTT.csv', 'w')
with myFile:
    writer = csv.writer(myFile)
    writer.writerows(mayor)
     
print("Writing complete")

