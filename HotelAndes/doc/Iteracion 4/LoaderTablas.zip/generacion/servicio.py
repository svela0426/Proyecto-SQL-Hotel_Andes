import random
import csv

mayor=[]
with open('a_servicio.csv') as File:
    reader = csv.reader(File, delimiter=',', quotechar=',',
                        quoting=csv.QUOTE_MINIMAL)
    cc=[]                    
    for row in reader:
        row.append(random.randint(1000000,6000000))
        cc.append(row)

        

print(cc[11])


myFile = open('a_servicio33.csv', 'w')
with myFile:
    writer = csv.writer(myFile)
    writer.writerows(cc)
     
print("Writing complete")
