import random
import csv
from datetime import datetime
from secrets import choice


49999
mayor=[]
for i in range(1,15000):
    lista=[]
    lista.append(i)
    lista.append(random.randint(1,5000))
    lista.append(random.randint(1,9999))
    mayor.append(lista)
    lista=[]


myFile = open('a_habitacion_reservada22.csv', 'w')
with myFile:
    writer = csv.writer(myFile)
    writer.writerows(mayor)
     
print("Writing complete")



