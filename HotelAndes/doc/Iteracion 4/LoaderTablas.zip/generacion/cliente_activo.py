import random
import csv
from datetime import datetime

mayor=[]

for i in range(1,50000):
    lista=[]
    lista.append(i)

    lista.append(random.randint(1,49999))

    mayor.append(lista)
    lista=[]

myFile = open('a_cliente_activo.csv', 'w')
with myFile:
    writer = csv.writer(myFile)
    writer.writerows(mayor)
     
print("Writing complete")
