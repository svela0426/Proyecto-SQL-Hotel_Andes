import random
import csv
from datetime import datetime

mayor=[]
for i in range(100000,200000):

    lista=[]
    lista.append(random.randint(1,10000))
    lista.append(i)
    mayor.append(lista)
    lista=[]




myFile = open('a_empleado.csv', 'w')
with myFile:
    writer = csv.writer(myFile)
    writer.writerows(mayor)
     
print("Writing complete")

