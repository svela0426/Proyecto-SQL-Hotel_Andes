import random
import csv
from datetime import datetime

mayor=[]
for i in range(5000,9000):
    lista=[]
    lista.append(i)
    lista.append(random.randint(200, 1783))
    mayor.append(lista)
    lista=[]

print(len(mayor))

myFile = open('a_cuenta_cargada.csv', 'w')
with myFile:
    writer = csv.writer(myFile)
    writer.writerows(mayor)
     
print("Writing complete")


