import random
import csv




lola= ["Suite" , "Junior suite" , "Gran suite"  ,"precidencial","famosos","apartmanet","house","full House", "KING","full loft","matrimoniales","familiares","pareaja" ]


types=["Individuales","Dobles" "Cuádruples","inmensa" ,"mixta" ,"entera" , "completa" ,"sin are", "con aire ", "con piscina" ,"sin piscina" , "con piscina con jacuzzi", "sin piscina con jacuzzi " , "con asistente" ,"sin asistente" ," alimentacion incluiuda" ,"vista al mar" , "vista piscina" , "2 camas" , "4 camas" , "5 camas"]

lili=[]


mayor=[]

for i in range(len(lola)):
    pala=" "
    for j in range(len(types)):
        pala=lola[i]+" "+types[j]
        lili.append(pala)
        pala=""


mayor=[]
for i in range(1,50000):
    lista1=[]
    pp="Habitacion "
    vocal=chr(random.randint(ord('A'), ord('A')))
    letra=random.choice("wrtypsdfghjklzcvbnm")
    pp=pp+vocal
    pp=pp+letra
    pp= pp +random.choice("wrtypsdfghjklzcvbnm")
    pp=pp+vocal
    pp= pp +random.choice("wrtypsdfghjklzcvbnm")
    pp=pp+chr(random.randint(ord('a'), ord('z')))
    pp=pp+vocal
    lista1.append(i)
    lista1.append(pp)
    lista1.append(random.choice(lili))
    lista1.append(i+50000)
    lista1.append(random.randint(1, 100000))

    mayor.append(lista1)
    lista1=[]



myFile = open('a_habitacion.csv', 'w')
with myFile:
    writer = csv.writer(myFile)
    writer.writerows(mayor)
     
print("Writing complete")
    
    














