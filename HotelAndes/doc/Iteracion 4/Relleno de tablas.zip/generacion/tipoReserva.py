import random
import csv

mayor=[]
for i in range(1,25000):
    lista=[]
    lista.append(i)
    lista.append(random.randint(1,49997))
    mayor.append(lista)
    lista=[]


print(len(mayor))

myFile = open('a_tipo_reserva.csv', 'w')
with myFile:
    writer = csv.writer(myFile)
    writer.writerows(mayor)
     
print("Writing complete")
    
    


