import random
import csv



mayor=[]
for i in range(1,100000):
    lista=[]
    lista.append(i)
    lista.append(random.randint( 3300000, 12000000))
    mayor.append(lista)
    lista=[]




myFile = open('a_cuenta.csv', 'w')
with myFile:
    writer = csv.writer(myFile)
    writer.writerows(mayor)
     
print("Writing complete")