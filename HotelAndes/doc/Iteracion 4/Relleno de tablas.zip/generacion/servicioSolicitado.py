import random
import csv
from datetime import datetime
from secrets import choice



inicio = datetime(2012, 1, 30)
final =  datetime(2014, 5, 28)

mayor=[]
for i in range(200,1782):
    lista=[]
    lista.append(i)
    lista.append(random.randint(5,20))
    lista.append(random.randint(1000000,4000000))
    random_date = inicio + (final - inicio) * random.random()

    pla=""
    day = str(random_date.day)
    pla=day+'/'
    mes = str(random_date.month)
    pla=pla+mes+'/'
    anio= str(random_date.year)
    pla=pla+anio
    lista.append(pla)

    mayor.append(lista)
    lista=[]




print(len(mayor))

myFile = open('a_servicio_solicitado33.csv', 'w')
with myFile:
    writer = csv.writer(myFile)
    writer.writerows(mayor)
     
print("Writing complete")