import random
import csv


lola= ["Suite" , "Junior suite" , "Gran suite"  ,"precidencial","famosos","apartmanet","house","full House", "KING","full loft","matrimoniales","familiares","pareaja" ]


types=["Individuales","Dobles" "Cuadruples","inmensa" ,"mixta" ,"entera" , "completa" ,"sin are", "con aire ", "con piscina" ,"sin piscina" , "con piscina con jacuzzi", "sin piscina con jacuzzi " , "con asistente" ,"sin asistente" ," alimentacion incluiuda" ,"vista al mar" , "vista piscina" , "2 camas" , "4 camas" , "5 camas"]

lili=[]

print(len(lola))
print(len(types))
mayor=[]

for i in range(len(lola)):
    pala=" "
    for j in range(len(types)):
        pala=lola[i]+" "+types[j]
        lili.append(pala)
        pala=""


for i in range(len(lili)):
    lista=[]
    lista.append(lili[i])
    lista.append(random.randint(1, 12))
    lista.append(random.randint(10, 40))
    mayor.append(lista)
    lista=[]


print(len(mayor))



myFile = open('a_tipo_habitacionNEW.csv', 'w')
with myFile:
    writer = csv.writer(myFile)
    writer.writerows(mayor)
     
print("Writing complete")