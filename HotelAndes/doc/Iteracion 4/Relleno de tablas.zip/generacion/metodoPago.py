import random
import csv

from datetime import datetime

with open('tarjetas.csv') as File:
    reader = csv.reader(File, delimiter=';', quotechar=';',
                        quoting=csv.QUOTE_MINIMAL)
    lista=[]                    
    for row in reader:
        lista.append(row[0])

lista=lista[2:]
tipo=["digital","fisico","online"]


mayor=[]
prove=[]
for i in range(100000):

  lista1=[]
  i=i+random.randint(1, 32000000000)
  if (i not in prove):
      prove.append(i)
      lista1.append(i)
      lista1.append(random.choice(tipo))
      lista1.append(random.choice(lista))
      mayor.append(lista1)
      lista1=[]

print(len(mayor))


myFile = open('a_metodo_pago.csv', 'w')
with myFile:
    writer = csv.writer(myFile)
    writer.writerows(mayor)
     
print("Writing complete")




 











