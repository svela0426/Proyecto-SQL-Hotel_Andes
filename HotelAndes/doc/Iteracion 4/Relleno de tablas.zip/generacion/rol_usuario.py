import random
import csv


estado=['Empleado', 'Cliente', 'Recepcionista','Organizador Eventos']

mayor=[]

for i in range(1,100001):
    lista=[]
    lista.append(i)
    lista.append('Cliente')
    mayor.append(lista)
    lista=[]


for j in range(100001,200001):
    lista1=[]
    lista1.append(j)
    lista1.append('Empleado')
    mayor.append(lista1)

    lista1=[]

for q in range(200001,250001):
    lista2=[]
    lista2.append(q)
    lista2.append('Recepcionista')
    mayor.append(lista2)
    lista2=[]

for q in range(250001,300001):
    lista22=[]
    lista22.append(q)
    lista22.append('Organizador Eventos')
    mayor.append(lista22)
    lista22=[]



myFile = open('a_rolusuario.csv', 'w')
with myFile:
    writer = csv.writer(myFile)
    writer.writerows(mayor)
     
print("Writing complete")