import random
import csv

from datetime import datetime

with open('names.csv') as File:
    reader = csv.reader(File, delimiter=';', quotechar=';',
                        quoting=csv.QUOTE_MINIMAL)
    lista=[]                    
    for row in reader:
        lista.append(row[0])

with open('apellido.csv') as File:
    reader = csv.reader(File, delimiter=';', quotechar=';',
                        quoting=csv.QUOTE_MINIMAL)
    lista1=[]                    
    for row in reader:
        lista1.append(row[0])


lista1=lista [1:]
lista=lista[1:]
print(lista1[0])


mayor=[]
for i in range(300000):
    ww="www."
    lista2=[]
    lista2.append(i)
    lista2.append(random.randint(1000000000, 3200000000))
    name=random.choice(lista)
    lista2.append(name +' '+random.choice(lista))
    apellido=random.choice(lista1)
    lista2.append(apellido)
    ww=ww+name+"_"+apellido+"_"+"_"+".@gmail.com"
    lista2.append(ww)
    mayor.append(lista2)
    lista2=[]

print(len(mayor))



myFile = open('a_usuarioNEW.csv', 'w')
with myFile:
    writer = csv.writer(myFile)
    writer.writerows(mayor)
     
print("Writing complete")


