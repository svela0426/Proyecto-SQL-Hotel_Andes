import random
import csv
from datetime import datetime


inicio = datetime(2012, 1, 30)
final =  datetime(2030, 5, 28)



with open('a_tipo_habitacionNEW.csv') as File:
    reader = csv.reader(File, delimiter=',', quotechar=',',
                        quoting=csv.QUOTE_MINIMAL)
    cc=[]                    
    for row in reader:
        cc.append(row[0])

print(cc)





mayor=[]


estados=['Activo','Inactivo','Pasada']



for j in range(1,10001):

    lisa=[]
    lisa.append(j)
    lisa.append(random.choice(cc))
    lisa.append(random.randint(2, 5))
    lisa.append(random.randint(2, 8))

    random_date = inicio + (final - inicio) * random.random()
    random_date1 = inicio + (final - inicio) * random.random()


    pla=""
    day = str(random_date.day)
    pla=day+'/'
    mes = str(random_date.month)
    pla=pla+mes+'/'
    anio= str(random_date.year)
    pla=pla+anio

    pla1=""
    day1 = str(random_date1.day)
    pla1=day1+'/'
    mes1 = str(random_date1.month)
    pla1=pla1+mes1+'/'
    anio1= str(random_date1.year)
    pla1=pla1+anio1

    if  anio <anio1  :
        lisa.append(pla)
        lisa.append(pla1)
    elif anio == anio1 :
        if mes <mes1:
            lisa.append(pla)
            lisa.append(pla1)
        else:
            lisa.append(pla1)
            lisa.append(pla)

    else:
            lisa.append(pla1)
            lisa.append(pla)






    
    lisa.append(random.choice(estados))

    mayor.append(lisa)
    lisa=[]


queso=cc[0]
print(queso)

print(queso[-1])



myFile = open('A_PLAN_PAGO_NEW.csv', 'w')
with myFile:
    writer = csv.writer(myFile)
    writer.writerows(mayor)
     
print("Writing complete")