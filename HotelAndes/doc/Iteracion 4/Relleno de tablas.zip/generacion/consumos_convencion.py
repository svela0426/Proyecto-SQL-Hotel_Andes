import random
import csv
from datetime import datetime

mayor=[]
for i in range(1,5001):
    lista=[]
    lista.append(i)
    lista.append(random.randint(200,1583))
    lista.append(random.randint(50,120))
    lista.append(random.randint(3000000,8000000))
    mayor.append(lista)
    lista=[]



myFile = open('a_consumos_convencion.csv', 'w')
with myFile:
    writer = csv.writer(myFile)
    writer.writerows(mayor)
     
print("Writing complete")
